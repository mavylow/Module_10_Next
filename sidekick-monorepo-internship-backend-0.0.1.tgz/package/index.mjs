import { cn as a, cm as c } from "./index-DEw3DZd-.mjs";
export {
  a as startMockingNotes,
  c as startMockingSocial
};
